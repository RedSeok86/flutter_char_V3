package vn.hunghd.flutterdownloader;

import androidx.core.content.FileProvider;

public class DownloadedFileProvider extends FileProvider {
}
