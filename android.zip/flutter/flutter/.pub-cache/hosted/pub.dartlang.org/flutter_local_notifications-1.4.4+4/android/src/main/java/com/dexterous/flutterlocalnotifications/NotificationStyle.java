package com.dexterous.flutterlocalnotifications;

public enum NotificationStyle{
    Default,
    BigPicture,
    BigText,
    Inbox,
    Messaging,
    Media
}

