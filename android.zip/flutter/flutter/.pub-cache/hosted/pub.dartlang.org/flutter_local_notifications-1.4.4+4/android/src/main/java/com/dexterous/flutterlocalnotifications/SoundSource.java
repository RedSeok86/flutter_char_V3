package com.dexterous.flutterlocalnotifications;

public enum SoundSource {
    RawResource,
    Uri
}
